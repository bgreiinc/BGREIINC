
async function loadProperties() {
  const res = await fetch('properties.json');
  const data = await res.json();
  return data;
}

function currency(n) {
  if (!n || n === 0) return '—';
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(n);
}

function card(p) {
  const img = (p.images && p.images[0]) ? p.images[0] : 'assets/placeholder_land.jpg';
  const price = currency(p.assignment_price);
  const badgeColor = p.status === 'Available' ? 'bg-green-100 text-green-700' :
                     p.status === 'Coming Soon' ? 'bg-yellow-100 text-yellow-700' :
                     'bg-gray-100 text-gray-700';
  return `
  <div class="bg-white rounded-2xl shadow hover:shadow-lg transition overflow-hidden">
    <img src="${img}" alt="${p.title}" class="w-full h-40 object-cover">
    <div class="p-4 space-y-2">
      <div class="flex items-center justify-between">
        <h3 class="font-semibold text-lg">${p.title}</h3>
        <span class="text-xs ${badgeColor} px-2 py-1 rounded-full">${p.status}</span>
      </div>
      <p class="text-sm text-slate-600">${p.address}</p>
      <div class="text-sm grid grid-cols-2 gap-2">
        <div><span class="text-slate-500">Type:</span> ${p.type || '—'}</div>
        <div><span class="text-slate-500">Ask:</span> ${price}</div>
        ${p.lot_size ? `<div><span class="text-slate-500">Lot:</span> ${p.lot_size}</div>` : ''}
        ${p.zoning ? `<div><span class="text-slate-500">Zoning:</span> ${p.zoning}</div>` : ''}
      </div>
      <p class="text-sm">${p.description || ''}</p>
      ${Array.isArray(p.notes) && p.notes.length ? `<ul class="text-xs text-slate-600 list-disc ml-5">${p.notes.map(n=>`<li>${n}</li>`).join('')}</ul>` : ''}
      <div class="pt-2 flex gap-2">
        <a href="mailto:cdale@bgreiinc.com?subject=Inquiry: ${encodeURIComponent(p.title)}"
           class="inline-flex items-center justify-center rounded-xl px-3 py-2 bg-sky-600 text-white text-sm hover:bg-sky-700">
           Request Packet
        </a>
        <button class="inline-flex items-center justify-center rounded-xl px-3 py-2 border text-sm"
                onclick="navigator.clipboard.writeText('${p.id}'); alert('Listing ID copied: ${p.id}')">
           Copy ID
        </button>
      </div>
    </div>
  </div>`;
}

function applyFilters(all) {
  const q = document.getElementById('search').value.trim().toLowerCase();
  const status = document.getElementById('status').value;
  return all.filter(p => {
    const hit = (p.title + ' ' + p.address + ' ' + (p.description||'')).toLowerCase().includes(q);
    const statusOk = status === 'ALL' ? true : p.status === status;
    return hit && statusOk;
  });
}

async function render() {
  const all = await loadProperties();
  const filtered = applyFilters(all);
  const grid = document.getElementById('grid');
  grid.innerHTML = filtered.map(card).join('');
  document.getElementById('count').textContent = filtered.length;
}

document.addEventListener('DOMContentLoaded', () => {
  ['search','status'].forEach(id => document.getElementById(id).addEventListener('input', render));
  render();
});
